﻿public class Inspector
{
    // 플레이어 전용

    // 입력 파라미터
    public const string PREFETCH = "Prefetched Data";

    // UI 전용
    public const string UI_TOP = "UI Top Component";
    public const string UI_COMPONENT = "UI Component";
    public const string UI_BOTTOM = "UI Bottom Component";
    public const string NEXT = "Next UI";

    // 던전 전용
    public const string DUNGEON_DATA = "Dungeon Settings";
}
